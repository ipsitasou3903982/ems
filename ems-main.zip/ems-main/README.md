# ems
Employee Management System

Steps To Run an Employee Management System
-----------------------------------------
1. Delete the old database table, not Database juts the tables (Total 3 tables will be there) 
2. Get the ems folder from the zip.
3. Paste it in the XAMPP inside the htdocs folder.
4. Open the folder in VS Code.
5. Open the terminal ( shortcut CTRL + ` )
6. Run - php spark serve
7. Run - php spark migrate
8. Run - php spark db:seed DatabaseSeeder
